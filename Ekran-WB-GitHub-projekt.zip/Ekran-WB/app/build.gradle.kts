plugins {
    id("com.android.application")
}

android {
    namespace = "pl.ekranwb"
    compileSdk = 35

    defaultConfig {
        applicationId = "pl.ekranwb"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
