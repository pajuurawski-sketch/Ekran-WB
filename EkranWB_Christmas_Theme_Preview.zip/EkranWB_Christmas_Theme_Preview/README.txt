Ekran W&B - Christmas theme preview

This ZIP contains the generated visual preview of the approved Christmas theme.
It is NOT a complete Android project or an updated APK.

The image is a static preview. To integrate the theme while preserving dynamic
order number, date/time, settings, remote control navigation, and app exit,
please upload the latest working Ekran-WB Android project ZIP.
