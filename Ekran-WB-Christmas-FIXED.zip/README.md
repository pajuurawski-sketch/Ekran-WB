# Ekran W&B

Aplikacja Android TV dla TCL Google TV / Android TV.

## Funkcje
- Pełnoekranowa tablica produkcyjna.
- Oryginalne logo firmy `logo-original.png` (plik skopiowany bez przerabiania).
- Ikona aplikacji przedstawia ekran telewizora.
- Edycja nagłówka i numeru zlecenia z poziomu przycisku koła zębatego.
- Stały rozmiar ramki nagłówka i automatyczne zmniejszanie czcionki przy dłuższym tekście.
- Data i godzina pobierane z zegara systemowego telewizora.
- Zapamiętywanie nagłówka i numeru zlecenia w pamięci aplikacji.
- Obsługa pilota Android TV.

## Budowanie przez GitHub Actions
1. Wgraj wszystkie pliki i foldery z tego projektu do repozytorium GitHub.
2. Otwórz zakładkę **Actions**.
3. Wybierz **Buduj Ekran W&B APK**.
4. Kliknij **Run workflow**.
5. Po zakończeniu otwórz wykonane zadanie i pobierz artefakt **Ekran-WB-APK**.
6. W środku znajduje się `app-debug.apk`.

## Ważne
Aplikacja jest przygotowanym projektem startowym. Pierwszy build należy sprawdzić na telewizorze TCL. Nie zawiera jeszcze zdalnego sterowania z telefonu ani synchronizacji przez Wi-Fi.
