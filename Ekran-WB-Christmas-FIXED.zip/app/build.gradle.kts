plugins {
    id("com.android.application")
}

android {
    namespace = "pl.ekranwb"
    compileSdk = 35

    defaultConfig {
        applicationId = "pl.ekranwb"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
}
