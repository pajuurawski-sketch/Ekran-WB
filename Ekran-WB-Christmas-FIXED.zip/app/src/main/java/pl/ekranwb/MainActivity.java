package pl.ekranwb;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.view.KeyEvent;

public class MainActivity extends Activity {
    private WebView webView;

    private void enterImmersiveMode() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        enterImmersiveMode();

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new ExitBridge(), "AndroidExit");
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        // Keep the TV display awake even while the WebView is showing the dashboard.
        webView.setKeepScreenOn(true);
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class ExitBridge {
        @JavascriptInterface
        public void closeApp() {
            runOnUiThread(() -> finish());
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enterImmersiveMode();
    }


    // Explicit TV remote mapping: arrows are navigation only; center/OK is confirm.
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN && webView != null) {
            String key = null;
            switch (event.getKeyCode()) {
                case KeyEvent.KEYCODE_DPAD_UP: key = "ArrowUp"; break;
                case KeyEvent.KEYCODE_DPAD_DOWN: key = "ArrowDown"; break;
                case KeyEvent.KEYCODE_DPAD_LEFT: key = "ArrowLeft"; break;
                case KeyEvent.KEYCODE_DPAD_RIGHT: key = "ArrowRight"; break;
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER: key = "Enter"; break;
                case KeyEvent.KEYCODE_BACK: return super.dispatchKeyEvent(event);
                default: break;
            }
            if (key != null) {
                final String jsKey = key;
                webView.evaluateJavascript(
                    "document.dispatchEvent(new KeyboardEvent('keydown',{key:'" + jsKey + "',bubbles:true,cancelable:true}));",
                    null
                );
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (webView != null) {
                webView.evaluateJavascript(
                    "if(window.closeSettingsFromBack){window.closeSettingsFromBack();}else{true;}", null
                );
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onResume() {
        super.onResume();
        enterImmersiveMode();
        if (webView != null) webView.setKeepScreenOn(true);
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
